﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace GZipCompression
{
    class GZipStreamClass
    {
        #region Приватные поля
        private static string operation = "";
        private static string copy;
        private static string firstNameOfUser;
        private static string secondNameOfUser;
        private static Regex regExp;
        private static bool returned;
        private static string line = "";
        #endregion


        #region 

        public static string Operation
        {
            get { return operation; }
            set { operation = value; }
        }
        public static string Copy
        {
            get { return copy; }
            set { copy = value; }
        }
        public static string FirstNameOfUser
        {
            get { return firstNameOfUser; }
            set { firstNameOfUser = value; }
        }
        public static string SecondNameOfUser
        {
            get { return secondNameOfUser; }
            set { secondNameOfUser = value; }
        }
        public static Regex RegExp
        {
            get { return regExp; }
            set { regExp = value; }
        }

        public static bool Returned
        {
            get { return returned; }
            set { returned = value; }
        }
        public static string Line
        {
            get { return line; }
            set { line = value; }
        } 
        #endregion
    }
}
