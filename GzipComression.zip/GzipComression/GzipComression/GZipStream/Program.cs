﻿using System;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;

namespace GZipCompression
{
    /// <summary>
    // Написать консольную программу на C#, 
    // предназначенную для поблочного сжатия и 
    // расжатия файлов с помощью System.IO.Compression.GzipStream. 
    /// </summary>
    public class Program
    {
        public static int Main(string[] args)
        {
            char OperationRepeat = 'X';
            GZipStreamClass.Line = args.ToString();
            do
            {
                Help();
                GZipStreamClass.Returned = true;
                FunctionGzip();
                Console.WriteLine("Xотите повторить еще? Y - Да. N - Нет.");
                OperationRepeat = Console.ReadKey().KeyChar;
                Console.WriteLine();
                if (OperationRepeat == 'y')
                   GZipStreamClass.Line = Console.ReadLine();
            } while(OperationRepeat != 'n');
            
            Console.WriteLine("Для выхода, пожалуйста, введите любую клавишу!");
            Console.ReadLine();
            if (GZipStreamClass.Returned)
                return 1;
            else
                return 0;
        }

        #region Mетоды

        /// <summary>
        /// Основной метод для выполнения задачи
        /// </summary>
        private static void FunctionGzip()
        {
            GZipStreamClass.Copy = @"^(\b((c|dec)ompress)\b\s[[][^\[\]]{1,50}[]]\s[[][^\[\]]{1,50}[]])$";
            try
            {
                //Создаем экземпляр для указанного регулярного выражения
                GZipStreamClass.RegExp = new Regex(GZipStreamClass.Copy); 
                //Если входная строка соответствует шаблону регулярного выражения, то выполняем
                //Иначе: выводим сообщение 
                if (GZipStreamClass.RegExp.IsMatch(GZipStreamClass.Line))
                {
                    Parser(GZipStreamClass.Line);

                    //Запускаем метод в зависимости от операции
                    MethodInfo method = Type.GetType("GZipStream.Program").GetMethod(GZipStreamClass.Operation);
                    method.Invoke(null, null);
                }
                else
                    throw new Exception("У вас есть ошибки в параметрах !\n");
            }
            catch (FileNotFoundException ex)
            {
                GZipStreamClass.Returned = false;
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                GZipStreamClass.Returned = false;
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Метод сжатия файла
        /// </summary>
        static public void compress()
        {
            string directory = Directory.GetCurrentDirectory();
            FileInfo fileToCompress = new FileInfo(directory + "\\" + GZipStreamClass.FirstNameOfUser);
            FileInfo archive = new FileInfo(directory + "\\" + GZipStreamClass.SecondNameOfUser);
            //Определяем наличие заданного файла.
            try
            {
                if (fileToCompress.Exists)
                {
                    using (FileStream originalFileStream = fileToCompress.OpenRead())
                    {
                        if ((File.GetAttributes(fileToCompress.FullName) & FileAttributes.Hidden) != FileAttributes.Hidden
                            & fileToCompress.Extension != ".gz")
                        {
                            using (FileStream compressFileStream = File.Create(archive.FullName + ".gz"))
                            {
                                using (System.IO.Compression.GZipStream compressionStream = new System.IO.Compression.GZipStream(compressFileStream, CompressionMode.Compress))
                                {
                                    originalFileStream.CopyTo(compressionStream);
                                }
                            }
                            FileInfo info = new FileInfo(archive.FullName + ".gz");
                            Console.WriteLine("Файл {0} сжат с {1} до {2} байт.",
                                fileToCompress.Name, fileToCompress.Length.ToString(), info.Length.ToString());
                        }
                    }
                }
                else
                    throw new FileNotFoundException(String.Format("Файл с именем {0} в каталоге {1} не найден", GZipStreamClass.FirstNameOfUser, directory));
            }
            catch {
                //Nothing to do
            };
                    
        }

        /// <summary>
        /// Метод разархивации
        /// </summary>
        static public void decompress()
        {
            string directory = Directory.GetCurrentDirectory();
            FileInfo fileToDeCompress = new FileInfo(directory + "\\" + GZipStreamClass.FirstNameOfUser);
            FileInfo archive = new FileInfo(directory + "\\" + GZipStreamClass.SecondNameOfUser);
            //Определяем наличие заданного файла.
            try
            {
                if (fileToDeCompress.Exists)
                {
                    using (FileStream originalFileStream = fileToDeCompress.OpenRead())
                    {

                        using (FileStream decompressFileStream = File.Create(GZipStreamClass.SecondNameOfUser))
                        {
                            using (System.IO.Compression.GZipStream decompressionStream = new System.IO.Compression.GZipStream(originalFileStream, CompressionMode.Decompress))
                            {
                                decompressionStream.CopyTo(decompressFileStream);
                                Console.WriteLine("Decompressed {0}", fileToDeCompress.Name);
                            }
                        }
                    }
                }
                else
                    throw new FileNotFoundException(String.Format("Архив с именем {0} в каталоге {1} не найден", GZipStreamClass.FirstNameOfUser, directory));
            }
            catch { };
        }

        /// <summary>
        /// Считывание строки
        /// </summary>
        private static void Parser(string inputString)
        {
            GZipStreamClass.Copy = @"\b((c|dec)ompress)\b";
            GZipStreamClass.RegExp = new Regex(GZipStreamClass.Copy);
            
            //Определяем операцию архивации/разархивации
            GZipStreamClass.Operation = GZipStreamClass.RegExp.Match(inputString).ToString();
            
            //Извлечь строку можно несколькими способами.
            inputString = DeConcat(inputString, GZipStreamClass.Operation); 

            GZipStreamClass.Copy = @"^([[][^\[\]]{1,50}[]])";
            GZipStreamClass.RegExp = new Regex(GZipStreamClass.Copy);
            
            //Запоминаем имя в первых квадратных скобках
            GZipStreamClass.FirstNameOfUser = GZipStreamClass.RegExp.Match(inputString).ToString(); 
            inputString = DeConcat(inputString, GZipStreamClass.FirstNameOfUser);
            
            //Убираем из имени квадратные скобки
            GZipStreamClass.FirstNameOfUser = GZipStreamClass.FirstNameOfUser.Substring(1, GZipStreamClass.FirstNameOfUser.Length - 2);
            
            //Запоминаем имя во вторых квадратных скобках 
            GZipStreamClass.SecondNameOfUser = GZipStreamClass.RegExp.Match(inputString).ToString(); 
            GZipStreamClass.SecondNameOfUser = GZipStreamClass.SecondNameOfUser.Substring(1, GZipStreamClass.SecondNameOfUser.Length - 2);
        }

        /// <summary>
        /// Удаление подстроки strFirst, strSecond
        /// </summary>
        public static string DeConcat(string strFirst, string strSecond)
        {
            return (string)strFirst.Substring(strFirst.IndexOf(strSecond) + strSecond.Length + 1);
        }

        private static void Help()
        {
            string helpMsg = string.Format("Для архивации: GZipTest.exe compress [имя исходного файла] [имя архива] \n"
                        + "Для разархивации: GZip.exe Decompress  [имя архива] [имя распакованного файла]");
            Console.WriteLine(helpMsg);
        }
        #endregion


    }

}
